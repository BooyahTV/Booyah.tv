# Booyah.tv 0.45
  ![app icon](48.png) Esta extención incorpora elementos de twitch.tv a booyah.live ![Wajaja](https://cdn.frankerfacez.com/emoticon/594021/1) Booyah ![Wajaja](https://cdn.frankerfacez.com/emoticon/594021/1) Booyah ![Wajaja](https://cdn.frankerfacez.com/emoticon/594021/1) Booyah


## Caracteristicas

1. Emotes incorporados sin nesesidad de configuración alguna
2. Nombres de usuario con colores
4. Panel de emotes
5. Poder ocultar las donaciones (fogatas, y esas weas)
6. Diseño similar a Twitch.tv (fuentes, etc)

### Chat
![Chat](readme/oldvsnew.png)
### Panel de Emotes
![Panel de Emotes](readme/emotepanel.png)
### Paneles
![Paneles](readme/paneles.png)

## Canales

Canales donde esta disponible la extensión:

* Cristianghost
* Dylantero
* [MoaiGR](https://booyah.live/channels/63681555)
* [Suwie](https://booyah.live/channels/71614581)
* [donsebastian](https://booyah.live/donsebastian)
* [puvlo](https://booyah.live/channels/62813927)

## Emotes

Emotes que estan incorporados:

* Emotes de twitch
* Emotes de subs
* [BetterTTV Global](https://betterttv.com)
* [Franker Face Z Global / del canal](https://www.frankerfacez.com)

#### Emotes de Twitch
| Nombre |   |
|--------|---|
|   LUL     |  ![](https://static-cdn.jtvnw.net/emoticons/v2/425618/default/dark/1.0) |
|     TehePelo   | ![](https://static-cdn.jtvnw.net/emoticons/v2/160404/default/dark/1.0) |
|    TriHard    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/120232/default/dark/1.0) |
|    Jebaited    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/114836/default/dark/1.0) |
|    cmonBruh    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/84608/default/dark/1.0) |
|    OSFrog    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/81248/default/dark/1.0) |
|    NotLikeThis    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/58765/default/dark/1.0) |
|    KappaPride    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/55338/default/dark/1.0) |
|    WutFace    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/28087/default/dark/1.0) |
|    BuddhaBar    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/27602/default/dark/1.0) |
|    BabyRage    | ![](https://static-cdn.jtvnw.net/emoticons/v2/22639/default/dark/1.0)  |
|    ANELE    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/3792/default/dark/1.0) |
|    BibleThump    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/86/default/dark/1.0) |
|    BloodTrail    | ![](https://static-cdn.jtvnw.net/emoticons/v2/69/default/dark/1.0)  |
|    Kreygasm    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/41/default/dark/1.0) |
|    Kappa    |  ![](https://static-cdn.jtvnw.net/emoticons/v2/25/default/dark/1.0) |

## Falta por implementar...


* Autocompletador de emotes de Franker Face Z (**:OMEGA..** y se despliega un panel de emotes)
* Popup
* Tooltip para los emotes (eso que sale al pasar por encima de un emote en el panel, sale el nombre del emote, canal,etc)
* Crear una version para Firefox, Safari,etc